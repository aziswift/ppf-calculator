import React from "react";

const ResultDisplay = ({ maturityAmount }) => {
  return (
    <div>
      <h2>Maturity Amount: ₹{maturityAmount}</h2>
    </div>
  );
};

export default ResultDisplay;
