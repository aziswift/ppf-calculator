import React, { useState } from "react";
import InvestmentPieChart from "./InvestmentPieChart"; // Your Pie Chart component
import InvestmentGrowthChart from "./InvestmentGrowthChart"; // Your Growth Chart component
import "./App.css";

const App = () => {
  const [maturityAmount, setMaturityAmount] = useState(null);

  const calculateMaturity = (e) => {
    e.preventDefault();
    // Replace this with your actual calculation logic
    setMaturityAmount(200000); // Example static value
  };

  return (
    <div className="App">
      <div className="header">PPF Calculator</div>

      <div className="form-container">
        <form onSubmit={calculateMaturity}>
          <input type="number" placeholder="Annual Contribution (₹)" required />
          <input
            type="number"
            placeholder="Investment Duration (Years)"
            required
          />
          <input type="number" placeholder="Interest Rate (%)" required />
          <button type="submit">Calculate</button>
        </form>
      </div>

      <div className="charts-container">
        <div className="chart-card">
          <h2>Investment Breakdown</h2>
          <InvestmentPieChart />
        </div>

        <div className="chart-card">
          <h2>Growth Over Time</h2>
          <InvestmentGrowthChart />
        </div>
      </div>

      {maturityAmount && (
        <div className="result-display">Maturity Amount: ₹{maturityAmount}</div>
      )}
    </div>
  );
};

export default App;
