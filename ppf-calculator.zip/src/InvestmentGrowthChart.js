import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

const data = [
  { year: "Year 1", amount: 50000 },
  { year: "Year 2", amount: 70000 },
  { year: "Year 3", amount: 90000 },
  { year: "Year 4", amount: 120000 },
];

const InvestmentGrowthChart = () => {
  return (
    <LineChart
      width={500}
      height={300}
      data={data}
      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
    >
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="year" />
      <YAxis />
      <Tooltip />
      <Legend />
      <Line type="monotone" dataKey="amount" stroke="#00b47e" />
    </LineChart>
  );
};

export default InvestmentGrowthChart;
