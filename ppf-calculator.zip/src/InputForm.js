import React, { useState } from "react";

const InputForm = ({ onCalculate }) => {
  const [duration, setDuration] = useState(15); // Default to 15 years
  const [interestRate, setInterestRate] = useState(8); // Default to 8%
  const [annualContribution, setAnnualContribution] = useState(50000); // Default to ₹50,000

  const handleSubmit = (e) => {
    e.preventDefault();
    onCalculate(duration, interestRate, annualContribution);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Investment Duration (years):</label>
        <input
          type="number"
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
        />
      </div>
      <div>
        <label>Interest Rate (%):</label>
        <input
          type="number"
          value={interestRate}
          onChange={(e) => setInterestRate(e.target.value)}
        />
      </div>
      <div>
        <label>Annual Contribution (₹):</label>
        <input
          type="number"
          value={annualContribution}
          onChange={(e) => setAnnualContribution(e.target.value)}
        />
      </div>
      <button type="submit">Calculate</button>
    </form>
  );
};

export default InputForm;
